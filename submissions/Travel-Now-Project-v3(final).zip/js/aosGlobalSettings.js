AOS.init({
    initClassName: 'aos',
    useClassNames: true,
    duration : 1000,
    once:true
});